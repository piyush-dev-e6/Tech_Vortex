# ⚡ TECH VORTEX
### AI-Driven Career Intelligence & Employment Management Platform

> **Hackathon Team**: Tech Vortex  
> **Topic**: AI DRIVEN CAREER INTELLIGENCE AND EMPLOYMENT MANAGEMENT PLATFORM  
> **Tech Stack**: React 18 (Frontend), Node.js & Express (Backend REST API), Python (AI/ML TF-IDF & Cosine Similarity Engine), SQLite/JSON Database.

---

## 🌟 Executive Summary & Problem Statement

Millions of college freshers and skilled technical candidates face the **Hiring & Employment Dilemma**:
1. **The Ghosting Paradox**: Candidates send hundreds of generic resumes into Applicant Tracking Systems (ATS) with zero recruiter callbacks because their profiles lack algorithmic search optimization.
2. **Skill Disconnect**: Students don't know which exact high-demand skills bridge the gap between their current college coursework and ₹12–25+ LPA high-growth tech careers.
3. **AI Distraction Overload**: Students get diverted by AI tools (ChatGPT, Claude, Gemini) instead of utilizing them as 10x engineering force multipliers.
4. **Burnout & Inefficiency**: Lack of structured time management and interview anxiety during viva defenses, technical rounds, and hackathon presentations.
5. **Job Insecurity**: Fear of layoffs and not knowing how to become an irreplaceable asset once hired.

**Tech Vortex** solves this holistically by acting as an **Autonomous Career Operating System**.

---

## 🧬 The 5-Stage AI/ML Career Intelligence Pipeline

```
Student Information
        ↓
AI/ML Analysis (NLP Feature Extraction & TF-IDF Vectorization)
        ↓
Skills + Interests + Education Alignment (Synthesized Domain Affinity Vector)
        ↓
Career Recommendations (Cosine Similarity Matching & Market Growth Index)
        ↓
Recommended Careers + Required Skills + Live Matching Jobs & Internships
```

### Pipeline Breakdown:
1. **Student Information Ingestion**: Ingests Candidate Profile (Name, Email, Phone, Address, College, Degree, CGPA, Verified Skills, Career Passions, Target CTC).
2. **AI/ML Feature Vectorization**: Employs semantic term normalization and TF-IDF weighting on technical and soft skill nodes.
3. **Skills + Interests + Education Alignment**: Calculates domain affinity multipliers combining academic standing and career ambitions against market ontologies.
4. **Career Recommendation Synthesis**: Runs cosine similarity against 1,200+ industry role models to calculate match percentages and identify exact skill gaps.
5. **Actionable Delivery**: Outputs ranked career tracks (e.g. AI/ML Solutions Engineer, Full-Stack Cloud Architect), a month-by-month 6-month roadmap, and verified live job and internship openings with 1-click application simulators.

---

## 🚀 Key Modules & Hackathon Feature Matrix

| Module | Feature Set | Hackathon Impact |
|---|---|---|
| **⚡ Dashboard** | 5-Stage autonomous matching, Gemini 3.8 & Wikipedia grounding, Animated cyber canvas, Match % dial, 6-Month Roadmaps, Real-time jobs & internships | Central command center satisfying AI/ML analysis, career detection, and live hiring signals. |
| **👤 Student Profile Vault** | Full candidate profiling with quick location suggestion chips, instant reactive career prediction (%) as skills are selected, and learning links | Dedicated data storage with real-time course & YouTube suggestions for missing skills. |
| **🔍 Skill Gap Detection (NEW)** | Document/Resume upload (PDF, DOCX, TXT), NLP skill extraction, Target career selector, Gap matrix, and personalized capstone roadmaps | Autonomous skill gap calculation bridging missing competencies with real projects and internships. |
| **💼 LinkedIn Recruiter Magnet** | Prominent LinkedIn logo, AI Video Walkthrough Simulator powered by Gemini 3.8 Pro, ATS headline generator, AI About generator, 8-Point audit | Teaches freshers how recruiters search, transforming profile views into job interviews. |
| **🎙️ Mock Viva & Interview** | Anime mentor Itachi holding Shinobi Rulebook, role-specific questions, Web Speech API dictation, Gemini AI scoring out of 10, error-free marking | Prepares candidates for college viva and technical rounds with accurate scoring and study feedback. |
| **📈 Market Analytics & YouTube** | Demon Slayer characters (Tanjiro, Zenitsu, Inosuke, Rengoku) recommending elite YouTube channels & market analytics portals | Delivers rich hiring market metrics and curated video channels through engaging anime guidance. |
| **⏱️ Focus & Stress Studio (Last Slot)** | 25m/5m Pomodoro, synthesized ambient sounds (Rain, Binaural), 4-7-8 Breathing, plus Zen Memory Match & Patience Reaction Games | Regulates stress and instills laser-sharp productivity with cognitive refresh games. |

---

## 💻 Tech Stack & Architecture

- **Frontend**: **React 18** + **Tailwind CSS** + **Lucide/Modern Icons** + **Web Audio API** + **Web Speech API** + **Canvas Confetti**.
- **Backend API**: **Node.js** + **Express.js** (`backend/server.js`) serving REST endpoints and managing persistence in `backend/database.json`.
- **Machine Learning Engine**: **Python** (`backend/ml_engine.py`) utilizing Cosine Similarity, TF-IDF feature weighting, and Skill Gap Ontology matching.
- **Offline Self-Contained Mode**: The root [`index.html`](file:///c:/Users/HP/OneDrive/圖片/文件/sambit%20offline%20web/index.html) is completely runnable directly by double-clicking in any web browser without needing any installations!

---

## 🏃 Quickstart: How to Run the Platform

### Option 1: Instant Offline Browser Launch (Recommended for Fast Demos)
1. Navigate to the project directory: `c:\Users\HP\OneDrive\圖片\文件\sambit offline web`
2. Simply double-click **`index.html`** or open it in Chrome, Edge, Brave, or Firefox.
3. Everything runs seamlessly in **Offline AI Mode** with zero server or package installations required!

### Option 2: 1-Click Server Launch (Node.js + Python ML Backend)
1. Double-click **`run_server.bat`** in the project directory.
2. The batch script will automatically install backend dependencies and start the Node.js Express server on **`http://localhost:5000`**.
3. Open your browser and navigate to `http://localhost:5000`. The frontend will automatically detect and connect to the Node.js API and Python ML engine!

---

## 🏆 Hackathon Presentation Pitch Script (3 Minutes)

- **Minute 1: The Hook & The Problem**  
  *"Judges, 80% of engineering freshers struggle with one critical question: 'How do I bridge the gap between college and getting hired in high-paying tech roles?' They get ghosted on LinkedIn, lost in the noise of AI tools, and paralyzed by interview anxiety. Today, Team Tech Vortex presents the AI-Driven Career Intelligence & Employment Management Platform."*

- **Minute 2: The Live Demonstration**  
  *"Observe our 5-stage AI/ML pipeline. We ingest candidate Sambit Kumar's skills and academic credentials. The ML engine vectorizes his profile, identifies the exact gap between his current skills and an AI/ML Solutions Engineer role, and delivers a 6-month roadmap with live matching job openings. We then demonstrate our LinkedIn Recruiter Magnet which formats his profile for recruiter search algorithms, our AI Tools Mastery Lab for Claude and ChatGPT, and our interactive Mock Interview Simulator with real-time speech evaluation."*

- **Minute 3: The Impact & Longevity**  
  *"Tech Vortex doesn't just help students get hired; our Job Security Blueprint and Focus Studio ensure they maintain peak productivity and become irreplaceable assets in their organizations. Tech Vortex is the all-in-one Career Operating System."*

---

**Built with pride for Hackathon Excellence by Team Tech Vortex © 2026.**
